<?php
	$conn=mysqli_connect("localhost","root","nsl","blood");
	if(!$conn)
		die("Error Connecting Database".mysqli_connect_error());
?>
